# DeadEnd v1.5.1 — input fixes + kit upgrades

This bundle fixes the "input isn't working properly" problem you reported
(sketch.dep and friends) and upgrades the kits with the "ready to go" tools
that were missing. Everything below was verified **live**: the compiler ran
inside a virtual display, synthetic mouse/keyboard events were injected into
the real compiled programs, and screenshots were taken of the actual windows
(see `verification/screenshots/`).

## TL;DR

Your input pipeline (compiler -> C -> raylib) was **never broken**. Two
separate things made it *look* broken:

1. **Bug 44 (the big one): `pressed "..."` never fired.** A key-state
   snapshot in the game loop was taken *after* raylib's event poll inside
   `EndDrawing()`, so the edge detector always compared the fresh state
   against itself and ate every press. Measured live: 0 fires across 30
   taps before the fix, exactly 1 fire per tap after. This is why
   `flappy.dep`, `animation-showcase.dep` and `menu-scene.dep` ignored
   keys while `pong.dep` (which only uses `holding`) worked fine.
2. **Bug 45: sketch.dep wiped itself every frame.** The example drew a
   line and then `clear "black"` erased it the very next frame, and its
   comments promised a right-click wipe and buttons that didn't exist.
   Rewritten as a real paint program (persistent strokes, undo, colors,
   brush size, working right-click wipe).

Plus the kit upgrades you asked for (all new sentences verified in a live
window):

- **Canvas** (game kit): a paint layer that remembers what you drew —
  `paint on canvas "art" ... end`, `show canvas "art" [at x, y [with size w, h]]`,
  `clear canvas "art" with "black"`, `save canvas "art" to "painting.png"`.
- **Timers**: `every 2 seconds ... end` inside `every frame`.
- **Camera**: `pan camera to x, y lasting 1 second feeling smooth`,
  `pan camera by dx, dy lasting ...`, `follow camera on hero.x, hero.y
  with speed 5`, `release camera`.
- **`mouse.wheel`** and **punctuation keys** (`pressed "-"`, `"="`, ...).
- **Language fix**: `add x to stroke.points` and friends (nested
  `add`/`remove` targets) — the old compiler rejected any target that
  wasn't a bare list name, which made list-of-maps programs impossible.

## What changed, file by file

| File | Change |
|------|--------|
| `lib/gamekit.c` | bug 44 (`dep_g_pressed` now uses raylib `IsKeyPressed`), bug 44 comment; `mouse.wheel`; punctuation key table; canvas API (open/close/show/clear/save + auto-create on first touch + cleanup before `CloseWindow`) |
| `lib/gamekit.h` | declarations for the canvas API |
| `lib/motionkit.c` | camera pan (persistent base offset + eased tween), follow (smoothed trail), `release camera`, `reset screen` homes the camera |
| `lib/motionkit.h` | declarations for the camera API |
| `src/dep_parse.py` | `paint on canvas`, `show/clear/save canvas`, `pan/follow/release camera`, `every N seconds` sentences |
| `src/dep_emit.py` | emitters for all of the above; nested `add`/`remove` targets (`_container_of`); recursive kit-check so app-kit programs get a clear error for game-only sentences |
| `examples/sketch.dep` | rewritten: persistent strokes, 4 colors, brush size, undo, right-click wipe |
| `examples/canvas-paint.dep` | NEW: canvas painter with mouse-wheel brush and PNG export |
| `docs/game-kit.md` | canvas + timers + wheel + punctuation keys |
| `docs/animation-kit.md` | camera section |
| `docs/language.md` | nested `add`, `every N seconds` |
| `README.md` | kit blurbs + example list |
| `FIXES.md` | full write-ups: bugs 44, 45, 46 + feature log |

## How to apply

Copy the files over your v1.5.0 tree (they are drop-in replacements; no
other file changed):

```
src/dep_parse.py, src/dep_emit.py
lib/gamekit.c, lib/gamekit.h, lib/motionkit.c, lib/motionkit.h
examples/sketch.dep, examples/canvas-paint.dep (new)
docs/game-kit.md, docs/animation-kit.md, docs/language.md
README.md, FIXES.md
```

Then clear the build cache so the fixed runtime is recompiled:

```
dec clean
```

Your raylib build is cached separately and is unaffected. `dec test`
passes 9/9 (2 kit tests skip without a display, same as before), and every
example in the tree builds clean with `dec build`.

## Evidence (verification/screenshots/)

| Screenshot | Shows |
|------------|-------|
| `sk_stroke2.png` | rewritten sketch: gold stroke persisted + sky-blue stroke drawn after pressing `2` (bug 44 fix live) |
| `sk_undo.png` | `z` removed the blue stroke, gold remains |
| `sk_wiped.png` | right-click wiped the canvas |
| `feat_painted.png` | canvas layer keeps paint across frames while the hero moves |
| `feat_pan.png` | `pan camera to 100, 50` shifted the world and stayed panned |
| `feature_shot.png` | `save canvas "art" to "feature_shot.png"` output — the exact texture the game drew |
| `paint_live.png` | canvas-paint example: smile curve + wheel-enlarged brush dot |
| `painting.png` | the PNG exported by `save canvas` from the live game |

## Reproduce the experiments yourself

`verification/` contains the harness used here (Linux, Xvfb + xdotool):

- `input_experiment.sh` + `probe.dep` — proves mouse events reach a
  compiled DeadEnd program (move / hold / click-edge / release).
- `sketch2_experiment.sh` — paints two strokes, undoes one, wipes, four
  screenshots.
- `features_experiment.sh` + `features.dep` — canvas + timer + camera +
  wheel + punctuation keys in one program.
- `paint_experiment.sh` — canvas-paint end-to-end including PNG export.
- `xshot.py` — X11 screenshot helper (no external deps beyond Pillow).

## Notes for your roadmaps (found while testing)

- App-kit typing was tested live and **works** (characters reach the
  field; the field shows its focus ring). If a user ever reports dead
  typing in a .dep app on Windows, check window focus first.
- `xdotool`-style sub-frame key taps can be missed by any event loop if
  press+release land inside one poll gap; real key holds cannot. Not a
  DeadEnd bug; noted so a future test harness uses keydown/keyup holds.
