# DeadEnd v1.4.0 — bug fixes

Every bug below was found by code review + an adversarial test battery, confirmed
against the unfixed code, fixed, and locked in by `tests/regression/` (11 cases),
the built-in suite (`dec test`, 11/11 including the kit tests under Xvfb), an
AddressSanitizer harness, a compile check of every example and every tour lesson,
and runtime runs of all 13 examples.

## Compiler front end (`src/dep_parse.py`)

1. **Bare built-ins rejected negative arguments.** The documented forms
   `abs -5`, `min -3, 9`, `random -1, 6` parsed as *subtraction*
   (`abs -5` → `abs() - 5`), so they failed with confusing errors.
   `_starts_neg_value` + `NEG_ARG_BUILTINS` now let a built-in math word take a
   negative first argument — while `x - 5` stays subtraction and
   `clock - 5` still means `clock() - 5`.

2. **`f()` as a statement parsed as `f(f())`.** `ping()` became a call to
   `ping` with one bogus argument (the result of a second, nested `ping()`
   call) — double-calling the function or dying with `unexpected ) in an
   expression`. `parse_callstmt` now reads a parenthesised argument list when
   the matching `)` ends the line.

3. **Statements carried no source line.** `set`, `change`, `print`, `if`,
   `while`, loops, `return`, `break`, `continue`, `exit` and friends had no
   line in the AST, which made correct runtime error reporting impossible
   (see bug 9). All statement tuples now carry their line.

## Compiler back end (`src/dep_emit.py`)

4. **UTF-8 text was mangled.** `c_str` kept only the low byte of every
   non-ASCII character (`日` → one wrong byte) and used `\xNN` escapes, which
   swallow following hex-looking characters. It now encodes the UTF-8 bytes
   exactly, with unambiguous 3-digit octal escapes.
   `"héllo wörld ✓ 日本語"` round-trips perfectly.

5. **Division by zero printed `inf` instead of erroring.** The typed
   fast path emitted raw C `a / b` (and `fmod(a, b)`), so `10 / 0` printed
   `inf` where the language reference promises
   `DeadEnd error (line 3): division by zero`. Both `/` and `%` now evaluate
   each side once and die with that exact message.

6. **Void results used as values broke the build.** `set r to say_hi()` where
   `say_hi` returns nothing produced a raw gcc error (`void value not
   ignored`) — or a Python `KeyError: 'void'` crash while declaring globals.
   Now: an English error (`'say_hi' doesn't give a value back ...`) at the
   right line, and `void` results can no longer poison type inference.

7. **Prelude contract mismatches.**
   - `dep_random1` (the 1-arg dice roll `random 6`) took a `DEPValue` while
     the emitter passes a plain `double` → *any* 1-arg `random` failed to
     compile with a gcc type error. Now `double`.
   - `dep_set_index2` released the index *after* `dep_set_index` had stored
     it as the map key — a textbook use-after-free for computed keys
     (`set m["k" + text i] to v` corrupts the heap; glibc aborts with
     `malloc(): unaligned tcache chunk detected`). The release is gone
     (ownership transfers; list indices are plain numbers).
   - `dep_save2` leaked the value it was handed (`save "f.txt", data`).

8. **Runtime errors all reported "line 1".** `__dep_line` existed in the
   runtime but generated code never wrote it. The emitter now emits
   `__dep_line = N;` before every statement (lines came from fix 3), so
   `dep_die` reports the true line — see `tests/regression/r01`.

## C runtime (`lib/dep_runtime.c`)

9. **Map hash-index double-insert.** After a grow-triggered `dep_map_rehash`
   (which already indexes the new entry), `dep_map_set` inserted the same
   entry into the open-addressing table *again* — a second slot pointing at
   one entry, breaking the table's invariants. The manual insert is skipped
   when a rehash just ran.

## Game kit (`lib/gamekit.c`)

10. **Music switched = music leaked.** `dep_g_music` loaded each new track
    over the old one without `UnloadMusicStream`, leaking the whole decoded
    stream (and its file handle) on every track change. The previous stream
    is now unloaded first (safe on a zeroed `Music` — verified in the vendored
    raylib: `UnloadAudioBuffer(NULL)` is a no-op).

11. **`dep_field_num` leaked every field read.** It dropped the owned value
    returned by `dep_field` — `hits` reads 8 fields per check, so a game
    checking collisions at 60 fps leaked continuously. Fixed with the missing
    `dep_release`.

12. **`dep_g_burst` leaked the particle-kind text** (`dep_cstr` borrows, the
    value was never released). Released after use.

## App kit (`lib/appkit.c`)

13. **`when button` on a non-button was a silent no-op.** Wiring
    `when button "out" is clicked` to a *label* silently registered nothing —
    the handler never ran and nothing explained why. `dep_app_on_click` now
    dies with `"out" is not a button, so 'when button "out" is clicked' would
    never run`.

## Motion kit (`lib/motionkit.c`)

14. **A tween never "finished" in small steps.** 120 ticks of 1/120 s sum to
    `0.9999999999999989`, so a 1-second tween was still `moving` after
    advancing a full second (and in a real 60 fps loop, a finished tween
    lingered for extra frames). The finish check now allows 1e-9 of slack.

15. **Pausing a timeline didn't pause steps already in flight.** `pause
    timeline` stopped the *schedule* but slots tick on independently, so the
    dot kept moving through the pause. Timelines now freeze the slots of
    running steps on pause and unfreeze them on resume / stop / play /
    `make timeline`.

## CLI (`src/dec.py`)

16. **`dec build file.dep -o`** (missing value) crashed with a Python
    traceback; `dec build -o out file.dep` treated `-o` as the program.
    Flag parsing now handles `-o` in any position and dies with a usage
    message; a missing output *directory* is created instead of crashing.

17. **`dec run --show-c file.dep`** treated `--show-c` as the file name
    (`cannot read --show-c`). Flags are now recognised in any position, and
    two program files is a clean usage error.

## Studio (`src/studio.py`)

18. **Windows cross-build failed to link every kit program.** The mingw
    command linked `gamekit.c` and `appkit.c` but not `motionkit.c`, so any
    game/app built through Studio's "Build for Windows" died with undefined
    references to `dep_m_*`. `motionkit.c` is on the link line now.

## Docs

19. **`docs/animation-kit.md` easing table contradicted the engine.**
    The engine maps `bouncy` → *bounce out* (`ease("bouncy", 0.5)` is
    0.765625), `snappy` → *back out*, `dramatic` → *expo in-out*; the table
    claimed back out / back in-out / bounce out. Corrected to match the code
    (the built-in `11-motion` test pins the numbers).

20. **`docs/language.md` showed a stray `end`** after the one-line `if`
    example, implying one-liners need `end` (they don't; typing it fails).

## Launchers / install (`dec`, `dec.bat`)

21. **`install.sh` installed a `dec` that could never run.** The launcher
    resolved the compiler as `$(dirname "$0")/src/dec.py`, but `install.sh`
    puts a *symlink* `~/.local/bin/dec -> <repo>/dec` on your PATH — and the
    dirname of the link is `~/.local/bin`, so every `dec` command died with
    `python3: can't open file '.../.local/bin/src/dec.py'` (verified by
    reproducing the exact install). Worse, any *other* copy of the launcher
    left on PATH from an older tree keeps shadowing the fixed one silently.
    The launcher now resolves the full symlink chain before locating
    `src/dec.py`.

22. **`dec.bat` changed the current directory.** It began with
    `cd /d "%~dp0"`, so a relative program path was resolved against the
    *launcher's* folder instead of yours (`dec run examples\pong.dep` from
    the repo root looked for `examples\examples\pong.dep`-style paths), and
    you could not tell *which* copy of DeadEnd was actually running when an
    older one was on PATH. dec.py locates all of its own files from its own
    location, so the `cd` was pure harm: removed. dec.bat now resolves every
    path from `%~dp0` and leaves your current directory alone.

23. **Stale `dec` copies were undetectable.** `dec version` now prints a
    build tag (`dec 1.4.0 -- DeadEnd compiler (build 2026-10-30)`, same in
    `dec doctor`), so if an older DeadEnd somewhere else on PATH answers,
    the missing/wrong tag exposes it immediately. See `UPGRADE.txt` for the
    two commands that fix a shadowed install.

## Kits on Windows (`src/dec.py`, new `tools/raylib`)

24. **The first kit program crashed with a Python traceback on Windows.**
    `build_raylib()` ran `sh vendor/raylib/build_raylib.sh` — there is no
    POSIX shell on Windows, so the very first `dec run <game>.dep` died with
    `FileNotFoundError: [WinError 2] The system cannot find the file
    specified` (reproduced from the user's traceback; and under Git-Bash it
    would have failed anyway, because the shell script cannot select the
    Win32 GLFW backend). raylib is now compiled **directly** with the C
    compiler and archived with `ar` (`_build_raylib_direct`): the exact same
    flags as the script (`-O2 -DPLATFORM_DESKTOP -DGRAPHICS_API_OPENGL_33`,
    `-D_GLFW_WIN32` on Windows / `-D_GLFW_X11` + `-fPIC` on Linux, with the
    ALSA-less retry for silent sound), nothing else needed. Verified two
    ways: a fresh-cache Linux build + kit game run, and a full MinGW-w64
    cross-build of raylib plus a link of a generated game-kit program to a
    PE32+ executable. Also: if no C compiler is installed, the failure is
    now a clean message with Windows install steps (was: traceback). And
    the package ships a **prebuilt win64 raylib** at
    `tools/raylib/libraylib.a` (which `raylib_dir()` already knew how to
    prefer), so on Windows the "building raylib" step usually never runs.

## Install (`install.bat`)

25. **`dec` only worked in the folder that contains `dec.bat`.** Opening a
    terminal anywhere else and typing `dec` produced `'dec' is not
    recognized as an internal or external command`. `install.bat` now adds
    step [4/4]: it writes a one-line `dec.cmd` shim into
    `%LOCALAPPDATA%\Microsoft\WindowsApps` (already on the per-user PATH)
    that forwards to the package's `dec.bat` — after installing once,
    `dec` works in every new terminal from every folder. Written with
    goto-flow (no parenthesised blocks) so package paths containing `(1)`
    cannot break batch parsing.

## Silent window death (`src/dec.py`, `lib/gamekit.c`, `lib/appkit.c`)

26. **Kit programs that failed to open a window died with zero output.**
    Reported live: `dec pong.dep` / `dec animated-todo.dep` returned to the
    prompt "like it opened and closed". The chain: the kits silence raylib's
    INFO log (`SetTraceLogLevel(LOG_WARNING)`), raylib's
    `WindowShouldClose()` returns `true` the moment the window is not
    ready, and `dec run` used `os.execv` — so a failed GLFW init or any
    startup crash produced an instant, *silent*, clean-looking exit. Three
    changes: `dec run` on Windows now runs the game as a child with the
    console attached and **decodes the exit code** (0xC0000135 missing DLL,
    0xC0000005 crash, plain 1 window-init failure — each with a hint, plus
    the built exe's path); `DEP_TRACE=1` now shows raylib's own init log
    (`Initializing raylib`, `GLFW: ...`, `DISPLAY: ...`) in both kits; and
    the failure is no longer invisible.

27. **Windows exes could depend on MinGW runtime DLLs.** Nothing forced
    `libgcc`/`libwinpthread` to link statically, so an exe built with a
    posix-threads MinGW could refuse to start on a machine without
    `libwinpthread-1.dll` — again silently, for a GUI-subsystem program.
    All Windows links now pass `-static`; the exe imports only system DLLs
    (verified: KERNEL32/USER32/GDI32/WINMM/SHELL32/msvcrt).

28. **`dec doctor` never tested the kit toolchain.** It compiled only a
    console hello-world, so "your gcc and the shipped/prebuilt raylib
    disagree" (ABI flavour mismatch) surfaced only as a silently closing
    game. Doctor now also *links* a kit program without running it and
    reports `kit link : PASS/FAIL`.

## Second review pass (2026-10-30b)

29. **Assignments inside nested loop bodies were invisible to the
    collector.** A variable assigned only inside a `repeat with` body
    nested in another `repeat with` (or a `for each` nested in a loop)
    never became a variable at all, so valid programs died with
    `'pairs' has no value` (at "line 0"). `_collect_assigns` now recurses
    into `repeat with` / `for each` bodies (the one-level `walk2` pass is
    gone). See `tests/regression/r12`.

30. **Statement-level calls stole the built-ins' comma arguments.**
    `print min 3, 9` failed with `min takes 2 value(s) but got 1` --
    and worse, `print random 1, 6` *silently* printed a dice roll and a
    stray 6 -- because bare calls inside a statement's argument list were
    forbidden from consuming commas (a rule meant for user functions).
    Multi-argument built-ins (`min`, `max`, `power`, `random`, `find`,
    `replace`, `split`, `join`) now keep their documented comma form
    everywhere. See `tests/regression/r13`.

31. **Keyword words were rejected as map keys and field names.**
    `set m to {times: 1}` died with "expected a key name in map", and
    reading it back with `m.times` died with "expected a field name".
    Map literals now accept any name-or-keyword word as a key, and `.`
    field access (read and write) accepts the same. See
    `tests/regression/r14`.

32. **`stop moving m[1]` crashed with a raw Python traceback.** Indexed
    targets cannot be animated, but the emitter unpacked `None` -- now it
    says `stop moving needs a target like score or dot.x -- indexed
    targets like m[1] are not animated` at the right line. Also,
    `stop moving dot.z` (a field that was never animated on an animated
    base) now errors instead of silently stopping every animation on
    `dot`. See `tests/regression/r15`.

33. **The `reversing` reverse leg snapped instead of animating.** The
    return leg's progress was read from the clamped cycle phase (always
    1.0), so a 1-second ping-pong teleported back in a single frame --
    and when the tween finished it wrote the far end again (`move x
    toward 100 lasting 1 second reversing` ended at 100 after visibly
    returning to 0). The phase is now taken within the current leg, and a
    finished ping-pong writes the start value. See
    `tests/regression/r16`.

34. **Timeline steps silently dropped `starting from N`.**
    `add move x toward 100 starting from 50 lasting 1 second to timeline
    "t"` started from the variable's current value. The override now
    travels through `dep_m_tl_add` (two new parameters, header updated)
    and applies when the step fires. See `tests/regression/r17`.

35. **`rain` / `snow` ignored their documented `life` option.**
    `rain 80 with color "light blue" and life 4` parsed `life` and threw
    it away (drops always died on landing). `dep_g_rain` / `dep_g_snow` /
    `dep_m_rain` / `dep_m_snow` now take the lifetime; an explicit life
    wins over the fall-time default.

36. **Studio's docs endpoint could read files outside docs/.**
    `/docs?page=../../src/dec.py` escaped the docs folder and served any
    `.md`-suffixed path under the package root as HTML. Page names are
    now validated (`[A-Za-z0-9_-]+`); anything else falls back to the
    language page.

37. **Studio's "For this PC" build button required the Windows
    toolchain.** The native build was gated on `can_windows` (MinGW
    present), so a Linux/macOS machine with a working gcc showed no way
    to build for its own OS. `/api/info` now reports `can_native` (via
    `dec.find_compiler`) and the button keys off that.

38. **Studio framed its preview camera at 480x640.** `game_size`
    defaulted to 480x640 while the game kit's window is 800x600, so
    preview screenshots of games without an explicit
    `make game ... width ...` were cropped wrong. Defaults now match the
    kit. `dec version` also prints build tag `2026-10-30b` so a tree with
    these fixes is distinguishable from one without them.

## Regression suite

`tests/regression/` holds one test per fixed behaviour
(`python3 tests/regression/run.py`) — line numbers, map key ownership,
negative args, `f()` statements, UTF-8, division by zero, void values,
`random n`, motion epsilon, pause freezing, and map churn -- plus, from
the second pass: nested-loop assignment collection, comma-separated
built-in arguments, keyword map keys, indexed `stop moving`, ping-pong
easing, and timeline `starting from` (r12-r17).

## Notes

- `clock`/`ALSA` warnings in the sandbox are environmental (no sound card),
  not bugs.
- raylib/X11 builds in this repo can be exercised headless with Xvfb:
  `Xvfb :99 &` then `DISPLAY=:99 DEP_FRAMES=3 dec run tests/09-game.dep`.

======================================================================
## v1.5.0 -- the "animation programs did nothing on Windows" pass
======================================================================

39. **Map-field animations always started from 0.**
    The generated read-back function for an animated map field
    (`dep_m_from_N`) walked to the map that holds the field and then
    checked the *map* for a number -- a map is never a number, so every
    `move ball.x toward ...` / spring / timeline step began from 0
    instead of the field's real value (deep fields like `a.b.x` too).
    The start value is now read from the field itself. Locked in by
    r18-motion-map-field and the corrected `11-motion` expectation (a
    reversing ping-pong now returns to its start value).

40. **A kit program without `run game` / `run app` compiled into a
    program that silently did nothing.** `every frame` and `when ...`
    handlers were registered, but nothing ever opened a window: the
    generated `main` returned 0 immediately, with no message and exit
    code 0 -- "the window never appears and cmd acts like I closed it".
    This is what the three v1.4.0 motion examples shipped as
    (`animation-showcase.dep`, `animated-todo.dep`, `menu-scene.dep`
    were missing the documented final `run` line). The compiler now
    rejects such programs with an error that says exactly what to add,
    and all three examples carry their `run` line. Locked in by
    r19-missing-run-game and r20-missing-run-app.

41. **A failed window init stayed silent.** raylib's `InitWindow`
    ignored its platform backend's failure return and kept going
    without a window or GL context; the game/app loop then saw "window
    closed" at once and the program exited with code 0 (on Linux it
    segfaulted). The vendored raylib now stops before using the device
    (`vendor/raylib/rcore.c`, marked "DeadEnd patch"), and both kits
    check `IsWindowReady()` right after `InitWindow` and die with an
    English explanation instead. The shipped prebuilt
    `tools/raylib/libraylib.a` was rebuilt from the patched source.

42. **Windows GUI-subsystem programs lost every error message.** Kit
    exes are linked with `-mwindows`, so `dep_die`'s stderr went into
    the void when the exe was run from a terminal. The runtime now
    attaches to the parent console at startup (`AttachConsole`) when
    the process has no standard handles yet, so errors are visible
    whether the program is started directly or through `dec run`.

43. **A dec upgrade kept serving a stale raylib.** The raylib build
    cache folder was shared across versions, so the patched vendored
    sources were not picked up on machines that had built raylib with
    an older dec. The cache folder is now version-specific
    (`raylib-<version>`). `dec version` prints build `2026-10-31a`.

## Regression suite (updated)

20 cases now: r18 locks the map-field start value, r19/r20 lock the
missing-`run` compile error for both kits. The built-in suite is
11/11 (the `11-motion` expectation was corrected: a reversing tween
ends where it started, not at 0).

# DeadEnd v1.5.1 — bug fixes + kit upgrades

Found by a live repro session (Xvfb + synthetic mouse/keyboard injection,
screenshots of the real window) plus code review, and verified the same way:
every fix below was confirmed against a screenshot or a printed probe before
and after. The full session transcript ships with the patch bundle.

## Input (this is the "input doesn't work" report)

44. **`pressed` never fired.** `dep_g_pressed` hand-rolled edge detection
    against a `dep_prev_keys` snapshot taken *after* `EndDrawing()` -- but
    raylib polls events *inside* `EndDrawing()` (`PollInputEvents` runs at
    its end), so the snapshot already contained the fresh press: `now ==
    was` and the edge was silently eaten. A key tap had to go down AND up
    inside a single frame gap to fire, which no human finger can do.
    Measured live: `pressed "p"` fired 0 times across 30 taps before the
    fix, exactly once per tap after. `flappy.dep`, `animation-showcase.dep`
    and `menu-scene.dep` all use `pressed`, which is why input seemed to
    work "only in some examples" (pong uses `holding`, which was always
    fine). `dep_g_pressed` now calls raylib's `IsKeyPressed`, whose
    previous/current comparison matches the "went down this frame"
    contract exactly.

45. **`sketch.dep` looked broken.** The example cleared the screen every
    frame, so every stroke lived for exactly one frame -- you dragged and
    saw nothing stick (screenshot-verified). Its header comment promised a
    right-click wipe while the code tested `mouse.click` (left), and the
    help bar advertised buttons that did not exist. Rewritten as a real
    paint program: strokes are stored in a list and redrawn every frame,
    right-click wipes, 1-4 pick colors, `-`/`+` change the brush, `z`
    undoes.

## Language

46. **`add ... to` and `remove ... from` only accepted a bare list name.**
    `add point to stroke.points` died with "needs a list name after 'to'".
    Since maps and lists are reference types (the same rule
    `set hero.x to ...` already uses), the emitter now accepts any target
    it accepts for `set`: `map.field`, `list[i]`, and chains of both
    (`stroke.points[i].x` reads were already fine).

## Game kit upgrades

- **`mouse.wheel`** -- vertical wheel this frame (+1 up, -1 down).
- **Punctuation keys** -- `pressed "-"`, `pressed "="`, `pressed "."` and
  friends now work (ASCII code = raylib key code for the printable
  punctuation set).
- **Canvas** -- a persistent offscreen paint layer:
  `paint on canvas "art"` ... `end` (drawing lands on the texture),
  `show canvas "art"` / `show canvas "art" at x, y` /
  `show canvas "art" at x, y with size w, h`,
  `clear canvas "art" with "color"` (auto-creates on first touch),
  `save canvas "art" to "file.png"`. Up to 8 canvases, freed on close.
  New example: `examples/canvas-paint.dep`.

## Motion kit upgrades

- **Camera control**: `pan camera to x, y lasting 1 second feeling smooth`,
  `pan camera by dx, dy lasting ...`, `follow camera on x, y with speed 5`
  (call it every frame; the camera trails the point), `release camera`
  (keeps the view exactly where it is), `reset screen` now also homes the
  camera. A finished pan parks in a resting base offset -- the view stays
  where you sent it instead of snapping home (this bug was caught by the
  same live screenshots during development).

## Compiler

- **`every N seconds`** -- timer blocks inside `every frame`:
  `every 2 seconds` ... `end` (also `milliseconds`). Per-site C static
  accumulator, no runtime changes. Compile-time error if used outside
  `every frame`, and a clear error if the program has no game kit.

# DeadEnd v1.5.1 -- tools build (2026-10-31c/d)

Built by actually making a real app with the language
(`examples/finance-dashboard.dep`, a custom-drawn finance dashboard) and
shipping the tools that were missing along the way:

## New commands

- **`dec watch file.dep`** -- runs your program and rebuilds + relaunches it
  every time you save. A save with an error prints the error and keeps the
  last good build running, so you never lose the window mid-edit. This is
  the single biggest speed-up for UI work: save, look, tweak, save.
- **`dec new <name> [app|game|blank]`** -- writes a commented starter file
  with the recommended structure (state, `when game starts`, `every frame`
  with input-then-drawing order, a final `run game`/`run app`).

## New sentence

- **`text width of <text> at <size>`** -- pixel width of a string in the
  font `write` uses (raylib default font). Centering and right-aligning
  text was guesswork before this; now it is one expression. Needs the game
  kit (it measures with raylib). Test: `tests/12-textwidth.dep`.

## New examples

- **`examples/finance-dashboard.dep`** -- a complete modern dashboard drawn
  with boxes, circles and text: sidebar pages, four switchable themes,
  animated counters, hover-tooltipped bar chart, budget donut, activity
  list, quick-add flow with toast. No images, no assets.
- **`examples/ui-kit.dep`** -- a component gallery: buttons (3 kinds,
  hover/press/disabled), chips, toggle, slider, input box, progress bar,
  donut ring, mini chart, toast, tooltip. Copy the functions into your own
  program for an instant UI vocabulary.

## Two language quirks found while building -- both now FIXED (2026-10-31d)

While building the dashboard, two compiler bugs surfaced. They shipped with
workarounds in the 2026-10-31c build; both are fixed properly now:

27. **A local first assigned from a function call was mis-typed as a
   number.** `set msg to label(7)` inside `every frame` declared `msg` as a
   C `double` and crashed (or printed garbage) at runtime. Root cause:
   local types were inferred during collection, *before* the parameter /
   return fixpoint had settled the callee's return type -- so the call
   contributed the initial "num" default and the wrong type was frozen.
   `analyze` now re-runs local-type inference after the signature fixpoint
   and alternates the two until stable (local types feed return types via
   `return some_local`, so they must be solved together).
   Regression: `tests/regression/r21-call-local-type.dep`. The type-anchor
   workaround in `finance-dashboard.dep` is no longer needed.
28. **A parenthesized expression starting with a built-in swallowed the
   whole interior as the call's argument.** `(abs n - w) * 100` parsed as
   `abs(n - w) * 100` because a bare call grabbed its argument with the
   full additive expression parser. A bare argument is now ONE value
   (parsed at unary level): `abs n - w` is `abs(n) - w`, matching the
   documented `abs -5` negative-argument rule (fix 1), and `abs (n - w)`
   still hands arithmetic to the call explicitly. Bare calls to your own
   functions parse the same way -- wrap arithmetic in parentheses when you
   want it inside the call.
   Regression: `tests/regression/r22-paren-builtin.dep`.
