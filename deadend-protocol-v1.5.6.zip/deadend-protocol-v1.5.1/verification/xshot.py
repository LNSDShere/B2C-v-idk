#!/usr/bin/env python3
"""Screenshot an X11 display region to PNG using ctypes + libX11.
Usage: xshot.py <display> <out.png> [x y w h]   (default: full root window)
"""
import ctypes, sys
from PIL import Image

display_name = sys.argv[1] if len(sys.argv) > 1 else ":99"
out = sys.argv[2] if len(sys.argv) > 2 else "/tmp/probe/shot.png"
region = [int(v) for v in sys.argv[3:7]] if len(sys.argv) >= 7 else None

X11 = ctypes.CDLL("libX11.so.6")
X11.XOpenDisplay.restype = ctypes.c_void_p
X11.XOpenDisplay.argtypes = [ctypes.c_char_p]
X11.XDefaultScreenOfDisplay.restype = ctypes.c_void_p
X11.XDefaultRootWindow.restype = ctypes.c_void_p
X11.XGetImage.restype = ctypes.c_void_p

d = X11.XOpenDisplay(display_name.encode())
if not d:
    sys.exit(f"cannot open display {display_name}")
scr = X11.XDefaultScreenOfDisplay(d)
W = X11.XWidthOfScreen(scr)
H = X11.XHeightOfScreen(scr)
root = X11.XDefaultRootWindow(d)
x, y, w, h = region if region else (0, 0, W, H)

img = X11.XGetImage(d, root, x, y, w, h, ~0, 2)  # ZPixmap=2
if not img:
    sys.exit("XGetImage failed")
# XImage layout (x86_64 linux): width@0 height@4 xoffset@8 format@12
# data@16 ... bytes_per_line@44, depth@48 (after bitmap_pad@36? verify below)
width = ctypes.c_int.from_buffer_copy(ctypes.c_void_p(img), ).value if False else None

# read fields via memoryview
buf = (ctypes.c_char * 128).from_address(img)
import struct
i_width, i_height, i_xoff, i_fmt = struct.unpack_from("iiii", buf, 0)
data_ptr = struct.unpack_from("P", buf, 16)[0]
byte_order, bitmap_unit, bitmap_bit_order, bitmap_pad, depth, bpl = \
    struct.unpack_from("iiiiii", buf, 24)

rows = []
for r in range(i_height):
    row = ctypes.string_at(data_ptr + r * bpl, i_width * 4)
    rows.append(row)

im = Image.frombytes("RGBX", (i_width, i_height), b"".join(rows), "raw", "BGRX")
im.convert("RGB").save(out)
print(f"saved {out} ({i_width}x{i_height} depth={depth})")
