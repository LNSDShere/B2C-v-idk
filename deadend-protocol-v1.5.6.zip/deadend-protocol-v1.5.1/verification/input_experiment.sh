#!/bin/bash
# Live input experiment: run probe.dep under Xvfb, inject synthetic mouse
# events with xdotool, capture what the DeadEnd program actually sees.
set -u
export DEP_SYSROOT=/home/z/.x11sysroot
export LD_LIBRARY_PATH=/home/z/.x11bin/usr/lib/x86_64-linux-gnu:${LD_LIBRARY_PATH:-}
XDOT=/home/z/.x11bin/usr/bin/xdotool
DEC=/home/z/my-project/b2c/extracted/deadend-protocol-v1.5.0/dec
export DISPLAY=:99

# start a virtual display with a 400x300 screen
Xvfb :99 -screen 0 640x480x24 &
XVFB_PID=$!
sleep 1.5

# compile+run the probe in the background; 240 frames ~= 4s at 60fps
cd /home/z/my-project/b2c/extracted/deadend-protocol-v1.5.0
DEP_FRAMES=240 "$DEC" run /home/z/my-project/scripts/probe.dep > /tmp/probe/out.txt 2>&1 &
PROG_PID=$!

sleep 3   # let the window open (first run also links the kit)

# --- synthetic input script -------------------------------------------
$XDOT mousemove 100 100   sleep 0.3
$XDOT mousemove 200 150   sleep 0.3
$XDOT mousedown 1         sleep 0.3
$XDOT mousemove 250 200   sleep 0.3
$XDOT mousemove 300 250   sleep 0.3
$XDOT mouseup 1           sleep 0.5
$XDOT click 1             sleep 0.5
$XDOT mousemove 50 50     sleep 0.5
# ----------------------------------------------------------------------

wait $PROG_PID
kill $XVFB_PID 2>/dev/null
echo "=== program output ==="
cat /tmp/probe/out.txt
