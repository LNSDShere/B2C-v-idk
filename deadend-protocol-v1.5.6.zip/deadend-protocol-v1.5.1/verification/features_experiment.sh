#!/bin/bash
# Feature verification: canvas + timer + camera + punctuation keys + wheel.
set -u
export DEP_SYSROOT=/home/z/.x11sysroot
export LD_LIBRARY_PATH=/home/z/.x11bin/usr/lib/x86_64-linux-gnu:${LD_LIBRARY_PATH:-}
XDOT=/home/z/.x11bin/usr/bin/xdotool
SHOT="python3 /home/z/my-project/scripts/xshot.py"
DEC=/home/z/my-project/b2c/extracted/deadend-protocol-v1.5.0/dec
export DISPLAY=:66

pkill -f "Xvfb" 2>/dev/null; sleep 0.8
rm -f /tmp/.X11-unix/X* /tmp/.X*-lock 2>/dev/null
Xvfb :66 -screen 0 640x480x24 > /tmp/probe/xvfb3.log 2>&1 &
XPID=$!
sleep 2

cd /home/z/my-project/b2c/extracted/deadend-protocol-v1.5.0
mkdir -p /tmp/probe/run && cd /tmp/probe/run
DEP_FRAMES=720 timeout 90 "$DEC" run /home/z/my-project/scripts/features.dep \
    > /tmp/probe/feat.log 2>&1 &
PROG_PID=$!
sleep 4.5    # window opens (400x300, centered at (120,90))

# 1. paint on the canvas: drag with left button
$XDOT mousemove 180 180 sleep 0.2
$XDOT mousedown 1
for p in "200 200" "220 240" "260 250" "300 220" "330 180"; do
  $XDOT mousemove $p sleep 0.15
done
$XDOT mouseup 1 sleep 0.4
$SHOT :66 /tmp/probe/feat_painted.png

# 2. timer ticks should be printing by now (1 per second)
# 3. move hero with keys, camera follows
$XDOT keydown Right sleep 0.4; $XDOT keyup Right sleep 0.2; $XDOT keydown Down sleep 0.4; $XDOT keyup Down sleep 0.2
$SHOT :66 /tmp/probe/feat_camfollow.png

# 4. pan camera away and release
$XDOT keydown p sleep 0.2; $XDOT keyup p sleep 0.8
$SHOT :66 /tmp/probe/feat_pan.png
$XDOT keydown r sleep 0.2; $XDOT keyup r sleep 0.2

# 5. save the canvas to a png
$XDOT keydown s sleep 0.2; $XDOT keyup s sleep 0.5

wait $PROG_PID
kill $XPID 2>/dev/null
echo "=== feat.log (timer ticks + errors) ==="
cat /tmp/probe/feat.log
echo "=== canvas png? ==="
ls -la /tmp/probe/run/feature_shot.png 2>&1
