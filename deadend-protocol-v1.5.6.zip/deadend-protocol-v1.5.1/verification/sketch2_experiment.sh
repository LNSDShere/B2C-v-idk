#!/bin/bash
# Sketch verification: paint strokes must persist, undo, wipe must work.
set -u
export DEP_SYSROOT=/home/z/.x11sysroot
export LD_LIBRARY_PATH=/home/z/.x11bin/usr/lib/x86_64-linux-gnu:${LD_LIBRARY_PATH:-}
XDOT=/home/z/.x11bin/usr/bin/xdotool
SHOT="python3 /home/z/my-project/scripts/xshot.py"
DEC=/home/z/my-project/b2c/extracted/deadend-protocol-v1.5.0/dec
export DISPLAY=:66

pkill -f "Xvfb" 2>/dev/null; sleep 0.8
rm -f /tmp/.X11-unix/X* /tmp/.X*-lock 2>/dev/null
Xvfb :66 -screen 0 640x480x24 > /tmp/probe/xvfb5.log 2>&1 &
XPID=$!
sleep 2

cd /home/z/my-project/b2c/extracted/deadend-protocol-v1.5.0
DEP_FRAMES=900 timeout 100 "$DEC" run examples/sketch.dep > /tmp/probe/sketch2.log 2>&1 &
PROG_PID=$!
sleep 4.5    # window: 600x400 at (20,40)

# stroke 1 (gold): a wave across the canvas
$XDOT mousemove 100 150 sleep 0.2
$XDOT mousedown 1
for p in "140 190" "190 230" "240 210" "290 170" "340 190" "390 230" "440 210"; do
  $XDOT mousemove $p sleep 0.12
done
$XDOT mouseup 1 sleep 0.4
$SHOT :66 /tmp/probe/sk_stroke1.png

# press 2 (sky blue) and stroke 2
$XDOT keydown 2 sleep 0.2; $XDOT keyup 2 sleep 0.3
$XDOT mousemove 150 300 sleep 0.2
$XDOT mousedown 1
for p in "220 330" "300 320" "380 340" "450 310"; do
  $XDOT mousemove $p sleep 0.12
done
$XDOT mouseup 1 sleep 0.4
$SHOT :66 /tmp/probe/sk_stroke2.png

# undo the blue stroke (z)
$XDOT keydown z sleep 0.2; $XDOT keyup z sleep 0.5
$SHOT :66 /tmp/probe/sk_undo.png

# redraw the blue stroke, then wipe everything (right-click)
$XDOT mousemove 150 300 sleep 0.2
$XDOT mousedown 1
for p in "220 330" "300 320" "380 340" "450 310"; do
  $XDOT mousemove $p sleep 0.1
done
$XDOT mouseup 1 sleep 0.4
$XDOT click 3 sleep 0.6
$SHOT :66 /tmp/probe/sk_wiped.png

wait $PROG_PID
kill $XPID 2>/dev/null
echo "=== sketch2.log ==="
cat /tmp/probe/sketch2.log
