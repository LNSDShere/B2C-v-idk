/* ==========================================================================
 * DeadEnd language runtime -- dep_runtime.c
 * Portable: builds on Linux, macOS and Windows (MinGW) with no extra deps.
 * ========================================================================== */
#include "dep_runtime.h"
#include <time.h>
#include <stdint.h>

#ifdef _WIN32
  #include <windows.h>
#else
  #include <sys/stat.h>
#endif

long __dep_line = 1;

/* ------------------------------------------------------------------ */
/* errors + alloc                                                      */
/* ------------------------------------------------------------------ */
void dep_die(const char *fmt, ...) {
    va_list ap;
    fflush(stdout);
    fprintf(stderr, "\nDeadEnd error (line %ld): ", __dep_line);
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fprintf(stderr, "\n");
    exit(1);
}

static void *dep_xmalloc(size_t n) {
    void *p = malloc(n ? n : 1);
    if (!p) dep_die("out of memory");
    return p;
}

const char *dep_typename(DEPValue v) {
    switch (v.tag) {
        case DEP_T_NOTHING: return "nothing";
        case DEP_T_NUM:     return "number";
        case DEP_T_TEXT:    return "text";
        case DEP_T_BOOL:    return "yes/no";
        case DEP_T_LIST:    return "list";
        case DEP_T_MAP:     return "map";
    }
    return "value";
}

/* ------------------------------------------------------------------ */
/* strings                                                             */
/* ------------------------------------------------------------------ */
DEPStr *dep_str_new(const char *data, long len) {
    DEPStr *s = (DEPStr *)dep_xmalloc(sizeof(DEPStr) + (size_t)len + 1);
    s->refs = 1;
    s->len = len;
    if (len > 0 && data) memcpy(s->chars, data, (size_t)len);
    s->chars[len] = '\0';
    return s;
}

DEPStr *dep_str_take(char *buf, long len) {
    DEPStr *s = dep_str_new(buf, len);
    free(buf);
    return s;
}

/* ------------------------------------------------------------------ */
/* constructors                                                        */
/* ------------------------------------------------------------------ */
DEPValue dep_nothing(void) { DEPValue v; v.tag = DEP_T_NOTHING; v.as.n = 0; return v; }
DEPValue dep_n(double x)   { DEPValue v; v.tag = DEP_T_NUM; v.as.n = x; return v; }
DEPValue dep_b(int x)      { DEPValue v; v.tag = DEP_T_BOOL; v.as.b = x ? 1 : 0; return v; }
DEPValue dep_s(const char *cstr) {
    DEPValue v; v.tag = DEP_T_TEXT;
    v.as.s = dep_str_new(cstr, (long)strlen(cstr));
    return v;
}
DEPValue dep_s_len(const char *data, long len) {
    DEPValue v; v.tag = DEP_T_TEXT;
    v.as.s = dep_str_new(data, len);
    return v;
}

/* ------------------------------------------------------------------ */
/* reference counting                                                  */
/* ------------------------------------------------------------------ */
void dep_retain_list(DEPList *l) { l->refs++; }
void dep_retain_map(DEPMap *m)   { m->refs++; }

void dep_release_list(DEPList *l) {
    if (--l->refs > 0) return;
    for (long i = 0; i < l->len; i++) dep_release(l->items[i]);
    free(l->items);
    free(l);
}

void dep_release_map(DEPMap *m) {
    if (--m->refs > 0) return;
    for (long i = 0; i < m->len; i++) {
        if (!m->entries[i].dead) {
            dep_release(m->entries[i].key);
            dep_release(m->entries[i].val);
        }
    }
    free(m->entries);
    free(m->index);
    free(m);
}

void dep_retain(DEPValue v) {
    switch (v.tag) {
        case DEP_T_TEXT: v.as.s->refs++; break;
        case DEP_T_LIST: v.as.l->refs++; break;
        case DEP_T_MAP:  v.as.m->refs++; break;
        default: break;
    }
}

void dep_release(DEPValue v) {
    switch (v.tag) {
        case DEP_T_TEXT: if (--v.as.s->refs <= 0) free(v.as.s); break;
        case DEP_T_LIST: dep_release_list(v.as.l); break;
        case DEP_T_MAP:  dep_release_map(v.as.m); break;
        default: break;
    }
}

/* ------------------------------------------------------------------ */
/* truthiness / equality / ordering                                    */
/* ------------------------------------------------------------------ */
int dep_truthy_b(int b) { return b != 0; }

int dep_truthy(DEPValue v) {
    switch (v.tag) {
        case DEP_T_BOOL:    return v.as.b;
        case DEP_T_NOTHING: return 0;
        case DEP_T_NUM:     return v.as.n != 0;
        case DEP_T_TEXT:    return v.as.s->len > 0;
        default:            return 1;
    }
}

static int dep_str_eq(DEPStr *a, DEPStr *b) {
    return a->len == b->len && memcmp(a->chars, b->chars, (size_t)a->len) == 0;
}

static int dep_str_cmp(DEPStr *a, DEPStr *b) {
    long minl = a->len < b->len ? a->len : b->len;
    int c = memcmp(a->chars, b->chars, (size_t)minl);
    if (c) return c;
    return a->len < b->len ? -1 : (a->len > b->len ? 1 : 0);
}

int dep_eq(DEPValue a, DEPValue b) {
    if (a.tag != b.tag) return 0;
    switch (a.tag) {
        case DEP_T_NUM:  return a.as.n == b.as.n;
        case DEP_T_TEXT: return dep_str_eq(a.as.s, b.as.s);
        case DEP_T_BOOL: return a.as.b == b.as.b;
        case DEP_T_LIST: return a.as.l == b.as.l;
        case DEP_T_MAP:  return a.as.m == b.as.m;
        default:         return 1;
    }
}

int dep_less(DEPValue a, DEPValue b) {
    if (a.tag == DEP_T_NUM && b.tag == DEP_T_NUM) return a.as.n < b.as.n;
    if (a.tag == DEP_T_TEXT && b.tag == DEP_T_TEXT) return dep_str_cmp(a.as.s, b.as.s) < 0;
    dep_die("cannot compare %s and %s with less than / more than", dep_typename(a), dep_typename(b));
    return 0;
}

/* ------------------------------------------------------------------ */
/* arithmetic                                                          */
/* ------------------------------------------------------------------ */
static void dep_num_op_check(DEPValue a, DEPValue b, const char *op) {
    if (a.tag != DEP_T_NUM || b.tag != DEP_T_NUM)
        dep_die("cannot %s %s and %s (numbers required)", op, dep_typename(a), dep_typename(b));
}

DEPValue dep_add(DEPValue a, DEPValue b) {
    if (a.tag == DEP_T_NUM && b.tag == DEP_T_NUM) return dep_n(a.as.n + b.as.n);
    if (a.tag == DEP_T_TEXT || b.tag == DEP_T_TEXT) {
        DEPValue ta = (a.tag == DEP_T_TEXT) ? a : dep_text_of(a);
        DEPValue tb = (b.tag == DEP_T_TEXT) ? b : dep_text_of(b);
        long la = ta.as.s->len, lb = tb.as.s->len;
        DEPStr *s = dep_str_new(NULL, la + lb);
        memcpy(s->chars, ta.as.s->chars, (size_t)la);
        memcpy(s->chars + la, tb.as.s->chars, (size_t)lb);
        if (a.tag != DEP_T_TEXT) dep_release(ta);
        if (b.tag != DEP_T_TEXT) dep_release(tb);
        DEPValue v; v.tag = DEP_T_TEXT; v.as.s = s; return v;
    }
    dep_die("cannot add %s and %s", dep_typename(a), dep_typename(b));
    return dep_nothing();
}

DEPValue dep_sub(DEPValue a, DEPValue b) { dep_num_op_check(a, b, "subtract"); return dep_n(a.as.n - b.as.n); }
DEPValue dep_mul(DEPValue a, DEPValue b) { dep_num_op_check(a, b, "multiply"); return dep_n(a.as.n * b.as.n); }
DEPValue dep_div(DEPValue a, DEPValue b) {
    dep_num_op_check(a, b, "divide");
    if (b.as.n == 0.0) dep_die("division by zero");
    return dep_n(a.as.n / b.as.n);
}
DEPValue dep_mod(DEPValue a, DEPValue b) {
    dep_num_op_check(a, b, "take the remainder of");
    if (b.as.n == 0.0) dep_die("division by zero");
    return dep_n(fmod(a.as.n, b.as.n));
}
DEPValue dep_neg(DEPValue a) {
    if (a.tag != DEP_T_NUM) dep_die("cannot negate %s", dep_typename(a));
    return dep_n(-a.as.n);
}

/* ------------------------------------------------------------------ */
/* lists                                                               */
/* ------------------------------------------------------------------ */
DEPList *dep_list_new(void) {
    DEPList *l = (DEPList *)dep_xmalloc(sizeof(DEPList));
    l->refs = 1; l->len = 0; l->cap = 0; l->items = NULL;
    return l;
}

DEPValue dep_list_value(DEPList *l) { DEPValue v; v.tag = DEP_T_LIST; v.as.l = l; return v; }

static void dep_list_grow(DEPList *l) {
    if (l->len < l->cap) return;
    l->cap = l->cap ? l->cap * 2 : 4;
    l->items = (DEPValue *)realloc(l->items, sizeof(DEPValue) * (size_t)l->cap);
    if (!l->items) dep_die("out of memory");
}

/* takes ownership of v */
void dep_list_push(DEPList *l, DEPValue v) {
    dep_list_grow(l);
    l->items[l->len++] = v;
}

static long dep_norm_index(double idx, long len, const char *what) {
    long i = (long)idx;
    if (idx != (double)i) dep_die("%s index must be a whole number (got %g)", what, idx);
    if (i < 0) i += len + 1;           /* -1 = last */
    if (i < 1 || i > len) dep_die("%s index %ld is out of range (1 to %ld)", what, i, len);
    return i;
}

DEPValue dep_list_get(DEPList *l, double idx) {
    long i = dep_norm_index(idx, l->len, "list");
    DEPValue v = l->items[i - 1];
    dep_retain(v);
    return v;
}

/* takes ownership of v */
void dep_list_set(DEPList *l, double idx, DEPValue v) {
    long i = dep_norm_index(idx, l->len, "list");
    dep_release(l->items[i - 1]);
    l->items[i - 1] = v;
}

/* takes ownership of v */
void dep_list_insert(DEPList *l, double idx, DEPValue v) {
    long i = (long)idx;
    if (idx != (double)i) dep_die("insert position must be a whole number (got %g)", idx);
    if (i < 0) i += l->len + 1;
    if (i < 1 || i > l->len + 1) dep_die("insert position %ld is out of range (1 to %ld)", i, l->len + 1);
    dep_list_grow(l);
    memmove(l->items + i, l->items + i - 1, sizeof(DEPValue) * (size_t)(l->len - i + 1));
    l->items[i - 1] = v;
    l->len++;
}

void dep_list_remove_at(DEPList *l, double idx) {
    long i = dep_norm_index(idx, l->len, "list");
    dep_release(l->items[i - 1]);
    memmove(l->items + i - 1, l->items + i, sizeof(DEPValue) * (size_t)(l->len - i));
    l->len--;
}

void dep_list_remove_value(DEPList *l, DEPValue v) {
    for (long i = 0; i < l->len; i++) {
        if (dep_eq(l->items[i], v)) {
            dep_retain(v);
            dep_release(l->items[i]);
            memmove(l->items + i, l->items + i + 1, sizeof(DEPValue) * (size_t)(l->len - i - 1));
            l->len--;
            dep_release(v);
            return;
        }
    }
}

static int dep_sort_cmp(const void *pa, const void *pb) {
    DEPValue a = *(const DEPValue *)pa, b = *(const DEPValue *)pb;
    if (a.tag == DEP_T_NUM && b.tag == DEP_T_NUM)
        return (a.as.n < b.as.n) ? -1 : (a.as.n > b.as.n ? 1 : 0);
    DEPValue ta = dep_text_of(a), tb = dep_text_of(b);
    int c = dep_str_cmp(ta.as.s, tb.as.s);
    dep_release(ta); dep_release(tb);
    return c;
}

void dep_list_sort(DEPList *l) { qsort(l->items, (size_t)l->len, sizeof(DEPValue), dep_sort_cmp); }

void dep_list_reverse(DEPList *l) {
    for (long i = 0, j = l->len - 1; i < j; i++, j--) {
        DEPValue t = l->items[i]; l->items[i] = l->items[j]; l->items[j] = t;
    }
}

void dep_list_shuffle(DEPList *l) {
    for (long i = l->len - 1; i > 0; i--) {
        long j = (long)dep_random(0, (double)i);
        DEPValue t = l->items[i]; l->items[i] = l->items[j]; l->items[j] = t;
    }
}

/* ------------------------------------------------------------------ */
/* maps (insertion-ordered entries + open-addressing index)            */
/* ------------------------------------------------------------------ */
static unsigned long dep_hash_value(DEPValue key) {
    if (key.tag == DEP_T_NUM) {
        uint64_t bits; memcpy(&bits, &key.as.n, 8);
        bits ^= bits >> 33; bits *= 0xff51afd7ed558ccdULL; bits ^= bits >> 33;
        return (unsigned long)bits;
    }
    if (key.tag == DEP_T_TEXT) {
        unsigned long h = 2166136261u;
        for (long i = 0; i < key.as.s->len; i++) { h ^= (unsigned char)key.as.s->chars[i]; h *= 16777619u; }
        return h;
    }
    dep_die("map keys must be text or numbers, not %s", dep_typename(key));
    return 0;
}

DEPMap *dep_map_new(void) {
    DEPMap *m = (DEPMap *)dep_xmalloc(sizeof(DEPMap));
    m->refs = 1; m->len = 0; m->cap = 0; m->entries = NULL;
    m->index = NULL; m->index_cap = 0; m->count = 0;
    return m;
}

DEPValue dep_map_value(DEPMap *m) { DEPValue v; v.tag = DEP_T_MAP; v.as.m = m; return v; }

static long dep_map_find(DEPMap *m, DEPValue key, unsigned long h) {
    if (m->index_cap == 0) return -1;
    long mask = m->index_cap - 1;
    long slot = (long)(h & (unsigned long)mask);
    for (;;) {
        long e = m->index[slot];
        if (e == -1) return -1;
        if (e >= 0) {
            DEPMapEntry *entry = &m->entries[e];
            if (!entry->dead && dep_eq(entry->key, key)) return e;
        }
        slot = (slot + 1) & mask;
    }
}

static void dep_map_rehash(DEPMap *m) {
    long want = m->count * 2 + 8;
    long cap = 16;
    while (cap < want * 2) cap <<= 1;
    free(m->index);
    m->index = (long *)dep_xmalloc(sizeof(long) * (size_t)cap);
    for (long i = 0; i < cap; i++) m->index[i] = -1;
    m->index_cap = cap;
    long mask = cap - 1;
    for (long e = 0; e < m->len; e++) {
        if (m->entries[e].dead) continue;
        long slot = (long)(dep_hash_value(m->entries[e].key) & (unsigned long)mask);
        while (m->index[slot] != -1) slot = (slot + 1) & mask;
        m->index[slot] = e;
    }
}

DEPValue dep_map_get(DEPMap *m, DEPValue key) {
    long e = dep_map_find(m, key, dep_hash_value(key));
    if (e < 0) return dep_nothing();
    DEPValue v = m->entries[e].val;
    dep_retain(v);
    return v;
}

/* takes ownership of key and val */
void dep_map_set(DEPMap *m, DEPValue key, DEPValue val) {
    if (key.tag != DEP_T_TEXT && key.tag != DEP_T_NUM)
        dep_die("map keys must be text or numbers, not %s", dep_typename(key));
    unsigned long h = dep_hash_value(key);
    long e = dep_map_find(m, key, h);
    if (e >= 0) {
        dep_release(m->entries[e].val);
        m->entries[e].val = val;
        dep_release(key); /* replaced: not stored */
        return;
    }
    if (m->len >= m->cap) {
        m->cap = m->cap ? m->cap * 2 : 8;
        m->entries = (DEPMapEntry *)realloc(m->entries, sizeof(DEPMapEntry) * (size_t)m->cap);
        if (!m->entries) dep_die("out of memory");
    }
    m->entries[m->len].key = key;
    m->entries[m->len].val = val;
    m->entries[m->len].dead = 0;
    m->len++; m->count++;
    int rehashed = 0;
    if ((m->count + 1) * 10 >= m->index_cap * 7) {
        dep_map_rehash(m);        /* rebuilds the index INCLUDING the new entry */
        rehashed = 1;
    }
    if (!rehashed && m->index_cap > 0) {
        long mask = m->index_cap - 1;
        long slot = (long)(h & (unsigned long)mask);
        while (m->index[slot] != -1) slot = (slot + 1) & mask;
        m->index[slot] = m->len - 1;
    }
}

/* takes ownership of val */
void dep_map_set_cstr(DEPMap *m, const char *key, DEPValue val) {
    /* find existing entry by raw string key */
    if (m->index_cap > 0) {
        long klen = (long)strlen(key);
        unsigned long h = 2166136261u;
        for (long i = 0; i < klen; i++) { h ^= (unsigned char)key[i]; h *= 16777619u; }
        long mask = m->index_cap - 1;
        long slot = (long)(h & (unsigned long)mask);
        for (;;) {
            long e = m->index[slot];
            if (e == -1) break;
            if (e >= 0 && !m->entries[e].dead && m->entries[e].key.tag == DEP_T_TEXT) {
                DEPStr *ks = m->entries[e].key.as.s;
                if (ks->len == klen && memcmp(ks->chars, key, (size_t)klen) == 0) {
                    dep_release(m->entries[e].val);
                    m->entries[e].val = val;
                    return;
                }
            }
            slot = (slot + 1) & mask;
        }
    }
    dep_map_set(m, dep_s(key), val);
}

void dep_map_set_field(DEPMap *m, const char *key, DEPValue val) {
    dep_map_set_cstr(m, key, val);
}

void dep_map_delete(DEPMap *m, DEPValue key) {
    unsigned long h = dep_hash_value(key);
    long e = dep_map_find(m, key, h);
    if (e < 0) return;
    DEPMapEntry *entry = &m->entries[e];
    entry->dead = 1;
    dep_release(entry->key); dep_release(entry->val);
    m->count--;
    if (m->index_cap > 0) {
        long mask = m->index_cap - 1;
        long slot = (long)(h & (unsigned long)mask);
        while (m->index[slot] != e) slot = (slot + 1) & mask;
        m->index[slot] = -2;
    }
    if (m->count == 0) { m->len = 0; dep_map_rehash(m); }
}

DEPList *dep_map_keys(DEPMap *m) {
    DEPList *l = dep_list_new();
    for (long i = 0; i < m->len; i++) {
        if (m->entries[i].dead) continue;
        DEPValue k = m->entries[i].key;
        dep_retain(k);
        dep_list_push(l, k);
    }
    return l;
}

/* ------------------------------------------------------------------ */
/* indexing                                                            */
/* ------------------------------------------------------------------ */
DEPValue dep_index(DEPValue coll, DEPValue idx) {
    if (coll.tag == DEP_T_LIST) {
        if (idx.tag != DEP_T_NUM) dep_die("list positions must be numbers, not %s", dep_typename(idx));
        return dep_list_get(coll.as.l, idx.as.n);
    }
    if (coll.tag == DEP_T_TEXT) {
        if (idx.tag != DEP_T_NUM) dep_die("letter positions must be numbers, not %s", dep_typename(idx));
        long i = dep_norm_index(idx.as.n, coll.as.s->len, "text");
        return dep_s_len(coll.as.s->chars + (i - 1), 1);
    }
    if (coll.tag == DEP_T_MAP) return dep_map_get(coll.as.m, idx);
    dep_die("cannot use [ ] on %s (lists, texts and maps only)", dep_typename(coll));
    return dep_nothing();
}

/* takes ownership of val */
void dep_set_index(DEPValue coll, DEPValue idx, DEPValue val) {
    if (coll.tag == DEP_T_LIST) {
        if (idx.tag != DEP_T_NUM) dep_die("list positions must be numbers, not %s", dep_typename(idx));
        dep_list_set(coll.as.l, idx.as.n, val);
        return;
    }
    if (coll.tag == DEP_T_MAP) { dep_map_set(coll.as.m, idx, val); return; }
    if (coll.tag == DEP_T_TEXT) dep_die("texts cannot be changed (build a new text instead)");
    dep_die("cannot use [ ] on %s", dep_typename(coll));
}

DEPValue dep_field(DEPValue map, const char *key) {
    if (map.tag != DEP_T_MAP)
        dep_die("only maps have fields like .%s (this value is %s)", key, dep_typename(map));
    DEPMap *m = map.as.m;
    if (m->index_cap > 0) {
        long klen = (long)strlen(key);
        unsigned long h = 2166136261u;
        for (long i = 0; i < klen; i++) { h ^= (unsigned char)key[i]; h *= 16777619u; }
        long mask = m->index_cap - 1;
        long slot = (long)(h & (unsigned long)mask);
        for (;;) {
            long e = m->index[slot];
            if (e == -1) break;
            if (e >= 0 && !m->entries[e].dead && m->entries[e].key.tag == DEP_T_TEXT) {
                DEPStr *ks = m->entries[e].key.as.s;
                if (ks->len == klen && memcmp(ks->chars, key, (size_t)klen) == 0) {
                    DEPValue v = m->entries[e].val;
                    dep_retain(v);
                    return v;
                }
            }
            slot = (slot + 1) & mask;
        }
    }
    return dep_nothing();
}

/* ------------------------------------------------------------------ */
/* printing (string-builder based: portable)                           */
/* ------------------------------------------------------------------ */
typedef struct { char *buf; size_t len, cap; } SB;

static void sb_grow(SB *sb, size_t need) {
    if (sb->len + need + 1 <= sb->cap) return;
    if (sb->cap == 0) sb->cap = 64;
    while (sb->len + need + 1 > sb->cap) sb->cap *= 2;
    sb->buf = (char *)realloc(sb->buf, sb->cap);
    if (!sb->buf) dep_die("out of memory");
}

static void sb_put(SB *sb, const char *s, size_t n) {
    sb_grow(sb, n);
    memcpy(sb->buf + sb->len, s, n);
    sb->len += n;
}

void dep_num_buf(double x, char *buf, int n) {
    if (x == (double)(long long)x && fabs(x) < 1e15)
        snprintf(buf, (size_t)n, "%lld", (long long)x);
    else
        snprintf(buf, (size_t)n, "%.14g", x);
}

static void dep_repr(DEPValue v, SB *sb, int depth) {
    char buf[40];
    switch (v.tag) {
        case DEP_T_NOTHING: sb_put(sb, "nothing", 7); break;
        case DEP_T_NUM:
            dep_num_buf(v.as.n, buf, 40);
            sb_put(sb, buf, strlen(buf));
            break;
        case DEP_T_TEXT:    sb_put(sb, v.as.s->chars, (size_t)v.as.s->len); break;
        case DEP_T_BOOL:    sb_put(sb, v.as.b ? "yes" : "no", v.as.b ? 3 : 2); break;
        case DEP_T_LIST: {
            if (depth > 24) { sb_put(sb, "[...]", 5); break; }
            sb_put(sb, "[", 1);
            for (long i = 0; i < v.as.l->len; i++) {
                if (i) sb_put(sb, ", ", 2);
                dep_repr(v.as.l->items[i], sb, depth + 1);
            }
            sb_put(sb, "]", 1);
            break;
        }
        case DEP_T_MAP: {
            if (depth > 24) { sb_put(sb, "{...}", 5); break; }
            sb_put(sb, "{", 1);
            int first = 1;
            for (long i = 0; i < v.as.m->len; i++) {
                if (v.as.m->entries[i].dead) continue;
                if (!first) sb_put(sb, ", ", 2);
                first = 0;
                dep_repr(v.as.m->entries[i].key, sb, depth + 1);
                sb_put(sb, ": ", 2);
                dep_repr(v.as.m->entries[i].val, sb, depth + 1);
            }
            sb_put(sb, "}", 1);
            break;
        }
    }
}

void dep_print(DEPValue v) {
    SB sb = {NULL, 0, 0};
    dep_repr(v, &sb, 0);
    sb_put(&sb, "\n", 1);
    fwrite(sb.buf, 1, sb.len, stdout);
    free(sb.buf);
}

void dep_show(DEPValue v) {
    SB sb = {NULL, 0, 0};
    dep_repr(v, &sb, 0);
    fwrite(sb.buf, 1, sb.len, stdout);
    free(sb.buf);
}
DEPValue dep_text_of(DEPValue v) {
    if (v.tag == DEP_T_TEXT) { dep_retain(v); return v; }
    SB sb = {NULL, 0, 0};
    dep_repr(v, &sb, 0);
    if (!sb.buf) { sb.buf = (char *)dep_xmalloc(1); sb.buf[0] = '\0'; }
    DEPValue r; r.tag = DEP_T_TEXT; r.as.s = dep_str_take(sb.buf, (long)sb.len);
    return r;
}

void dep_print_many(DEPValue *vals, long n) {
    SB sb = {NULL, 0, 0};
    for (long i = 0; i < n; i++) {
        if (i) sb_put(&sb, " ", 1);
        dep_repr(vals[i], &sb, 0);
    }
    sb_put(&sb, "\n", 1);
    fwrite(sb.buf, 1, sb.len, stdout);
    free(sb.buf);
}

void dep_print_num(double x) {
    char buf[40];
    dep_num_buf(x, buf, 40);
    fputs(buf, stdout);
    fputc('\n', stdout);
}

DEPValue dep_ask(const char *prompt) {
    if (prompt && *prompt) { fputs(prompt, stdout); fflush(stdout); }
    size_t cap = 64, len = 0;
    char *buf = (char *)dep_xmalloc(cap);
    int c;
    while ((c = fgetc(stdin)) != EOF && c != '\n') {
        if (len + 2 > cap) {
            cap *= 2;
            buf = (char *)realloc(buf, cap);
            if (!buf) dep_die("out of memory");
        }
        buf[len++] = (char)c;
    }
    while (len > 0 && (buf[len - 1] == '\r' || buf[len - 1] == ' ')) len--;
    buf[len] = '\0';
    DEPValue v; v.tag = DEP_T_TEXT;
    v.as.s = dep_str_take(buf, (long)len);
    return v;
}

double dep_clock(void) {
#ifdef _WIN32
    static LARGE_INTEGER freq, t0;
    static int inited = 0;
    if (!inited) { QueryPerformanceFrequency(&freq); QueryPerformanceCounter(&t0); inited = 1; }
    LARGE_INTEGER now;
    QueryPerformanceCounter(&now);
    return (double)(now.QuadPart - t0.QuadPart) / (double)freq.QuadPart;
#else
    static struct timespec t0;
    static int inited = 0;
    struct timespec now;
    if (!inited) { clock_gettime(CLOCK_MONOTONIC, &t0); inited = 1; }
    clock_gettime(CLOCK_MONOTONIC, &now);
    return (double)(now.tv_sec - t0.tv_sec) + (double)(now.tv_nsec - t0.tv_nsec) / 1e9;
#endif
}

/* ------------------------------------------------------------------ */
/* text builtins                                                       */
/* ------------------------------------------------------------------ */
static void dep_need_text(DEPValue v, const char *who) {
    if (v.tag != DEP_T_TEXT) dep_die("%s needs text, got %s", who, dep_typename(v));
}

DEPValue dep_number_of(DEPValue v) {
    if (v.tag == DEP_T_NUM) { dep_retain(v); return v; }
    if (v.tag != DEP_T_TEXT) return dep_nothing();
    const char *p = v.as.s->chars;
    while (*p == ' ' || *p == '\t') p++;
    if (!*p) return dep_nothing();
    char *end;
    double d = strtod(p, &end);
    if (end == p) return dep_nothing();
    while (*end == ' ' || *end == '\t') end++;
    if (*end) return dep_nothing();
    return dep_n(d);
}

DEPValue dep_upper(DEPValue v) {
    dep_need_text(v, "upper");
    DEPStr *s = dep_str_new(v.as.s->chars, v.as.s->len);
    for (long i = 0; i < s->len; i++)
        if (s->chars[i] >= 'a' && s->chars[i] <= 'z') s->chars[i] -= 32;
    DEPValue r; r.tag = DEP_T_TEXT; r.as.s = s; return r;
}

DEPValue dep_lower(DEPValue v) {
    dep_need_text(v, "lower");
    DEPStr *s = dep_str_new(v.as.s->chars, v.as.s->len);
    for (long i = 0; i < s->len; i++)
        if (s->chars[i] >= 'A' && s->chars[i] <= 'Z') s->chars[i] += 32;
    DEPValue r; r.tag = DEP_T_TEXT; r.as.s = s; return r;
}

DEPValue dep_trim(DEPValue v) {
    dep_need_text(v, "trim");
    const char *p = v.as.s->chars, *q = p + v.as.s->len;
    while (p < q && (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r')) p++;
    while (q > p && (q[-1] == ' ' || q[-1] == '\t' || q[-1] == '\n' || q[-1] == '\r')) q--;
    return dep_s_len(p, (long)(q - p));
}

DEPValue dep_split(DEPValue s, DEPValue sep) {
    dep_need_text(s, "split");
    dep_need_text(sep, "split separator");
    if (sep.as.s->len == 0) dep_die("split separator cannot be empty");
    DEPList *l = dep_list_new();
    const char *p = s.as.s->chars, *start = p;
    long slen = s.as.s->len, k = sep.as.s->len;
    for (long i = 0; i + k <= slen; ) {
        if (memcmp(p + i, sep.as.s->chars, (size_t)k) == 0) {
            dep_list_push(l, dep_s_len(start, (long)(p + i - start)));
            i += k;
            start = p + i;
        } else i++;
    }
    dep_list_push(l, dep_s_len(start, (long)(p + slen - start)));
    return dep_list_value(l);
}

DEPValue dep_join(DEPValue list, DEPValue sep) {
    if (list.tag != DEP_T_LIST) dep_die("join needs a list, got %s", dep_typename(list));
    dep_need_text(sep, "join separator");
    SB sb = {NULL, 0, 0};
    for (long i = 0; i < list.as.l->len; i++) {
        if (i) sb_put(&sb, sep.as.s->chars, (size_t)sep.as.s->len);
        DEPValue t = dep_text_of(list.as.l->items[i]);
        sb_put(&sb, t.as.s->chars, (size_t)t.as.s->len);
        dep_release(t);
    }
    if (!sb.buf) { sb.buf = (char *)dep_xmalloc(1); sb.buf[0] = '\0'; }
    DEPValue r; r.tag = DEP_T_TEXT; r.as.s = dep_str_take(sb.buf, (long)sb.len);
    return r;
}

static const char *dep_memfind(const char *hay, long hlen, const char *needle, long nlen) {
    if (nlen == 0) return hay;
    if (nlen > hlen) return NULL;
    for (long i = 0; i + nlen <= hlen; i++)
        if (hay[i] == needle[0] && memcmp(hay + i, needle, (size_t)nlen) == 0) return hay + i;
    return NULL;
}

DEPValue dep_find(DEPValue hay, DEPValue needle) {
    if (hay.tag == DEP_T_TEXT && needle.tag == DEP_T_TEXT) {
        const char *found = dep_memfind(hay.as.s->chars, hay.as.s->len,
                                        needle.as.s->chars, needle.as.s->len);
        return dep_n(found ? (found - hay.as.s->chars) + 1 : 0);
    }
    if (hay.tag == DEP_T_LIST) {
        for (long i = 0; i < hay.as.l->len; i++)
            if (dep_eq(hay.as.l->items[i], needle)) return dep_n(i + 1);
        return dep_n(0);
    }
    dep_die("find needs text in text, or a value in a list (got %s)", dep_typename(hay));
    return dep_nothing();
}

DEPValue dep_replace(DEPValue s, DEPValue from, DEPValue to) {
    dep_need_text(s, "replace");
    dep_need_text(from, "replace pattern");
    dep_need_text(to, "replace target");
    if (from.as.s->len == 0) dep_die("replace pattern cannot be empty");
    if (from.as.s->len > s.as.s->len) { dep_retain(s); return s; }
    long count = 0;
    for (long i = 0; i + from.as.s->len <= s.as.s->len; )
        if (memcmp(s.as.s->chars + i, from.as.s->chars, (size_t)from.as.s->len) == 0) { count++; i += from.as.s->len; }
        else i++;
    long newlen = s.as.s->len + count * (to.as.s->len - from.as.s->len);
    DEPStr *r = dep_str_new(NULL, newlen);
    long wp = 0;
    for (long i = 0; i < s.as.s->len; ) {
        if (i + from.as.s->len <= s.as.s->len &&
            memcmp(s.as.s->chars + i, from.as.s->chars, (size_t)from.as.s->len) == 0) {
            memcpy(r->chars + wp, to.as.s->chars, (size_t)to.as.s->len);
            wp += to.as.s->len; i += from.as.s->len;
        } else {
            r->chars[wp++] = s.as.s->chars[i++];
        }
    }
    DEPValue v; v.tag = DEP_T_TEXT; v.as.s = r; return v;
}

int dep_has(DEPValue collection, DEPValue value) {
    if (collection.tag == DEP_T_TEXT && value.tag == DEP_T_TEXT)
        return dep_find(collection, value).as.n > 0;
    if (collection.tag == DEP_T_LIST)
        return dep_find(collection, value).as.n > 0;
    if (collection.tag == DEP_T_MAP)
        return dep_map_find(collection.as.m, value, dep_hash_value(value)) >= 0;
    dep_die("has needs a text, list or map on the left, got %s",
            dep_typename(collection));
    return 0;
}

long dep_count(DEPValue v) {
    switch (v.tag) {
        case DEP_T_TEXT: return v.as.s->len;
        case DEP_T_LIST: return v.as.l->len;
        case DEP_T_MAP:  return v.as.m->count;
        default: dep_die("count of needs a text, list or map, got %s", dep_typename(v)); return 0;
    }
}

DEPValue dep_first(DEPValue v) {
    if (v.tag == DEP_T_LIST) {
        if (v.as.l->len == 0) return dep_nothing();
        DEPValue r = v.as.l->items[0]; dep_retain(r); return r;
    }
    if (v.tag == DEP_T_TEXT) {
        if (v.as.s->len == 0) return dep_nothing();
        return dep_s_len(v.as.s->chars, 1);
    }
    dep_die("first of needs a text or list, got %s", dep_typename(v));
    return dep_nothing();
}

DEPValue dep_last(DEPValue v) {
    if (v.tag == DEP_T_LIST) {
        if (v.as.l->len == 0) return dep_nothing();
        DEPValue r = v.as.l->items[v.as.l->len - 1]; dep_retain(r); return r;
    }
    if (v.tag == DEP_T_TEXT) {
        if (v.as.s->len == 0) return dep_nothing();
        return dep_s_len(v.as.s->chars + v.as.s->len - 1, 1);
    }
    dep_die("last of needs a text or list, got %s", dep_typename(v));
    return dep_nothing();
}

/* ------------------------------------------------------------------ */
/* files                                                               */
/* ------------------------------------------------------------------ */
DEPValue dep_load_file(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return dep_nothing();
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (n < 0) { fclose(f); return dep_nothing(); }
    char *buf = (char *)dep_xmalloc((size_t)n + 1);
    size_t got = fread(buf, 1, (size_t)n, f);
    fclose(f);
    DEPValue v; v.tag = DEP_T_TEXT;
    v.as.s = dep_str_take(buf, (long)got);
    return v;
}

void dep_save_file(const char *path, DEPValue v) {
    FILE *f = fopen(path, "wb");
    if (!f) dep_die("cannot write file '%s'", path);
    DEPValue t = (v.tag == DEP_T_TEXT) ? v : dep_text_of(v);
    fwrite(t.as.s->chars, 1, (size_t)t.as.s->len, f);
    fclose(f);
    if (v.tag != DEP_T_TEXT) dep_release(t);
}

DEPValue dep_exists_file(const char *path) {
    FILE *f = fopen(path, "rb");
    if (f) { fclose(f); return dep_b(1); }
    return dep_b(0);
}

/* ------------------------------------------------------------------ */
/* random                                                              */
/* ------------------------------------------------------------------ */
static uint64_t dep_rng_state = 0x9E3779B97F4A7C15ULL;

void dep_random_seed(unsigned long seed) {
    dep_rng_state = seed ? (uint64_t)seed : 0x9E3779B97F4A7C15ULL;
}

static uint64_t dep_rng_next(void) {
    uint64_t x = dep_rng_state;
    x ^= x << 13; x ^= x >> 7; x ^= x << 17;
    return dep_rng_state = x;
}

double dep_random(double lo, double hi) {
    if (hi < lo) { double t = lo; lo = hi; hi = t; }
    double u = (double)(dep_rng_next() >> 11) / 9007199254740992.0; /* [0,1) 53 bits */
    double r;
    if (lo == (double)(long long)lo && hi == (double)(long long)hi &&
        fabs(lo) < 1e15 && fabs(hi) < 1e15 && hi - lo < 9007199254740992.0) {
        r = lo + floor(u * (hi - lo + 1.0));      /* dice: inclusive integers */
        if (r < lo) r = lo;
        if (r > hi) r = hi;
    } else {
        r = lo + u * (hi - lo);
    }
    return r;
}

/* ------------------------------------------------------------------ */
/* lifecycle                                                           */
/* ------------------------------------------------------------------ */
void dep_init(void) {
    /* Studio / pipes: make prints appear immediately, prompts included. */
    setvbuf(stdout, NULL, _IOLBF, 0);
#ifdef _WIN32
    /* Bug fix (42): kit programs are linked with -mwindows, so Windows gives
       them no console and every error message vanished into nothing. Attach
       to the parent console (when the exe is started from a terminal) and
       redirect stdout/stderr onto it. Only when the process has no valid
       standard handles yet, so real redirections (Studio, pipes) stay put. */
    {
        HANDLE err = GetStdHandle(STD_ERROR_HANDLE);
        HANDLE out = GetStdHandle(STD_OUTPUT_HANDLE);
        if ((err == NULL || err == INVALID_HANDLE_VALUE) &&
            (out == NULL || out == INVALID_HANDLE_VALUE) &&
            AttachConsole(ATTACH_PARENT_PROCESS)) {
            freopen("CONOUT$", "w", stdout);
            freopen("CONOUT$", "w", stderr);
        }
    }
#endif
    dep_rng_state ^= (uint64_t)time(NULL) * 0xD1B54A32D192ED03ULL;
    dep_rng_state ^= (uint64_t)clock() << 17;
    if (!dep_rng_state) dep_rng_state = 0x9E3779B97F4A7C15ULL;
}

void dep_shutdown(void) {
    fflush(stdout);
}

#ifndef DEP_NO_MAIN
int main(int argc, char **argv) {
    (void)argc; (void)argv;
    dep_init();
    int rc = dep_main();
    dep_shutdown();
    return rc;
}
#endif
