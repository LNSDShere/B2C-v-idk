/* ==========================================================================
 * DeadEnd 2D Game Kit -- gamekit.h
 * All DEPValue parameters are CONSUMED (the kit releases them).
 * ========================================================================== */
#ifndef DEP_GAMEKIT_H
#define DEP_GAMEKIT_H

#include "dep_runtime.h"

typedef struct {
    char  *title;
    double width, height, fps;
    int    fullscreen;
    void (*on_start)(void);
    void (*on_frame)(void);
} DEPGameConfig;

extern DEPGameConfig dep_game_config;
extern int dep_window_open;   /* shared by game kit and app kit */

/* lifecycle */
void dep_game_setup(DEPValue title, double w, double h, double fps, int fullscreen);
void dep_game_run(void);

/* input */
int  dep_g_holding(DEPValue key);   /* is the key held down right now */
int  dep_g_pressed(DEPValue key);   /* did the key go down this frame */
DEPMap *dep_g_mouse(void);          /* map with x, y, left, right, click, rclick */

/* drawing (inside every frame) */
void dep_g_clear(DEPValue color);
void dep_g_pixel(double x, double y, DEPValue color);
void dep_g_line(double x1, double y1, double x2, double y2, DEPValue color);
void dep_g_box(double x, double y, double w, double h, DEPValue color);
void dep_g_circle(double x, double y, double r, DEPValue color);
void dep_g_ring(double x, double y, double r, DEPValue color);
void dep_g_write(DEPValue text, double x, double y, double size, DEPValue color);
void dep_g_image3(DEPValue file, double x, double y);
void dep_g_image5(DEPValue file, double x, double y, double w, double h);
void dep_g_image_frame(DEPValue file, double x, double y, double w, double h,
                       double n, double m, double flip_v, double flip_h);
void dep_g_image_part(DEPValue file, double x, double y, double w, double h,
                      double sx, double sy, double sw, double sh,
                      double flip_v, double flip_h);

/* canvas: a persistent offscreen paint layer (v1.5.1) */
void dep_g_canvas_open(DEPValue name);      /* paint on canvas "n" ... end */
void dep_g_canvas_close(void);              /* emitted at the block's end */
void dep_g_canvas_show(DEPValue name, int has_xy, double x, double y,
                       int has_wh, double w, double h);
void dep_g_canvas_clear(DEPValue name, DEPValue color);
void dep_g_canvas_save(DEPValue name, DEPValue file);   /* export to .png */
void dep_g_canvases_unload(void);           /* game loop cleanup */

/* audio */
void dep_g_sound(DEPValue file);
void dep_g_music(DEPValue file);
void dep_g_silence(void);

/* timing + misc */
double dep_g_time(void);
double dep_g_delta(void);
/* v1.5.1 tools: pixel width of text in the default font, so programs can
   center and right-align labels: `set x to 400 - text width of "Hi" at 20` */
double dep_g_text_width(DEPValue s, double size);
int    dep_g_hits(DEPValue a, DEPValue b);  /* AABB collision of two maps */
void   dep_set_title(DEPValue title);       /* works for games and apps */

/* ---- motion kit (v1.4.0): game-side wrappers + render hooks ---- */
void dep_g_draw_particles(void);            /* called by the game loop */
void dep_g_shake(double strength, double dur);
void dep_g_flash(DEPValue color, double dur);
void dep_g_fade_to(DEPValue color, double dur);
void dep_g_fade_from(DEPValue color, double dur);
void dep_g_zoom(double target, double dur, DEPValue feel);
void dep_g_burst(DEPValue kind, double n, double x, double y,
                 DEPValue color, double speed, double size, double life);
void dep_g_rain(double n, DEPValue color, double speed, double size,
                double life);
void dep_g_snow(double n, DEPValue color, double speed, double size,
                double life);

#endif /* DEP_GAMEKIT_H */
