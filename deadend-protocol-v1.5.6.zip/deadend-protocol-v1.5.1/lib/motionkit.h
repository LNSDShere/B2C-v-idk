/* ==========================================================================
 * DeadEnd Motion Kit -- motionkit.h   (new in v1.4.0)
 *
 * The animation engine behind DeadEnd.  Pure C, no raylib: the game kit and
 * app kit pull state OUT of this engine each frame and render it.  That keeps
 * the engine linkable in console-only programs, where `advance` steps time by
 * hand.
 *
 *   move dot.x toward 300 lasting 2 seconds feeling bouncy
 *   spring dot.y toward 80 with wobble 6
 *   make timeline "intro" ... play timeline "intro"
 *   burst 30 sparks at 200, 150        shake screen with strength 8
 *   pop in button "Go"                 fade to black lasting 1 second
 * ========================================================================== */
#ifndef DEP_MOTIONKIT_H
#define DEP_MOTIONKIT_H

#include "dep_runtime.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ---- easing curves (31) ----
   ids: 0 linear; then per family in/out/in-out:
   1-3 sine, 4-6 quad, 7-9 cubic, 10-12 quart, 13-15 quint,
   16-18 expo, 19-21 circ, 22-24 back, 25-27 elastic, 28-30 bounce */
enum {
    DEP_EASE_LINEAR = 0,
    DEP_EASE_SINE_IN, DEP_EASE_SINE_OUT, DEP_EASE_SINE_INOUT,
    DEP_EASE_QUAD_IN, DEP_EASE_QUAD_OUT, DEP_EASE_QUAD_INOUT,
    DEP_EASE_CUBIC_IN, DEP_EASE_CUBIC_OUT, DEP_EASE_CUBIC_INOUT,
    DEP_EASE_QUART_IN, DEP_EASE_QUART_OUT, DEP_EASE_QUART_INOUT,
    DEP_EASE_QUINT_IN, DEP_EASE_QUINT_OUT, DEP_EASE_QUINT_INOUT,
    DEP_EASE_EXPO_IN, DEP_EASE_EXPO_OUT, DEP_EASE_EXPO_INOUT,
    DEP_EASE_CIRC_IN, DEP_EASE_CIRC_OUT, DEP_EASE_CIRC_INOUT,
    DEP_EASE_BACK_IN, DEP_EASE_BACK_OUT, DEP_EASE_BACK_INOUT,
    DEP_EASE_ELASTIC_IN, DEP_EASE_ELASTIC_OUT, DEP_EASE_ELASTIC_INOUT,
    DEP_EASE_BOUNCE_IN, DEP_EASE_BOUNCE_OUT, DEP_EASE_BOUNCE_INOUT
};

double dep_m_ease(int curve, double t);            /* 0..1 -> 0..1 */
int    dep_m_ease_id(const char *name);            /* feeling or curve name, -1 unknown */
double dep_m_ease_call(DEPValue feel, DEPValue t); /* builtin: ease "bouncy" 0.5 */

/* ---- slots: one animatable DeadEnd target (global var or map field) ----
   The generated code binds each slot to read/write callbacks so the engine
   can move real DeadEnd variables every frame. */
void   dep_m_bind(int id, double (*from_fn)(void), void (*write_fn)(double));

/* tween; feel may be NULL (defaults to smooth). repeat: -1 forever, else
   number of plays. has_from overrides the starting value (else the slot's
   bound target is read when the tween actually starts). */
void   dep_m_move(int id, const char *feel, double to, double dur,
                  double delay, double repeat_n, int pingpong,
                  double from, int has_from);
/* physics spring; stiffness/damping < 0 -> defaults */
void   dep_m_spring(int id, double to, double stiffness, double damping);

int    dep_m_active(int id);                       /* tween/spring in flight */
double dep_m_value(int id);                        /* current animated value  */
void   dep_m_stop(int id);
void   dep_m_stop_range(int lo, int hi);           /* inclusive */
void   dep_m_stop_all(void);
int    dep_m_any_active(void);

/* ---- timelines (found-or-created by name) ---- */
void   dep_m_tl_new(const char *name);
void   dep_m_tl_add(const char *name, int slot, const char *feel, double to,
                    double dur, double delay, double repeat_n, int pingpong,
                    double stiffness, double damping, int is_spring,
                    int together, double from_override, int has_from);
void   dep_m_tl_add_wait(const char *name, double dur, int together);
void   dep_m_tl_add_ui(const char *name, int op, const char *target, double dur,
                       const char *feel, int dir, double x, double y,
                       double strength, int together);
void   dep_m_tl_play(const char *name, double repeat_n);
void   dep_m_tl_pause(const char *name);
void   dep_m_tl_resume(const char *name);
void   dep_m_tl_stop(const char *name);
int    dep_m_tl_playing(const char *name);
int    dep_m_tl_finished(const char *name);

/* ---- UI motion (app kit). ops: ---- */
enum {
    DEP_UI_POP_IN = 0, DEP_UI_POP_OUT, DEP_UI_FADE_IN, DEP_UI_FADE_OUT,
    DEP_UI_SLIDE_IN, DEP_UI_SLIDE_OUT, DEP_UI_SHAKE, DEP_UI_BUMP, DEP_UI_GLIDE
};
/* slide dirs: 0 left, 1 right, 2 top, 3 bottom */
void   dep_m_ui_exec(int op, const char *name, double dur, const char *feel,
                     int dir, double x, double y, double strength);
void   dep_m_set_ui_exec(void (*fn)(int op, const char *name, double dur,
                                    const char *feel, int dir, double x,
                                    double y, double strength));
/* state the app kit reads while drawing (alpha/scale persist after done) */
int    dep_m_ui_state(const char *name, double *dx, double *dy,
                      double *alpha, double *scale, int *hidden);

/* ---- screen fx (state read by the game kit) ---- */
void   dep_m_shake(double strength, double dur);
void   dep_m_flash(double r, double g, double b, double dur);
void   dep_m_fade_to(double r, double g, double b, double dur);
void   dep_m_fade_from(double r, double g, double b, double dur);
void   dep_m_zoom(double target, double dur, const char *feel);
void   dep_m_reset_screen(void);
int    dep_m_camera(double *ox, double *oy, double *zoom);
int    dep_m_overlay(double *r, double *g, double *b, double *a);

/* ---- camera pan + follow (v1.5.1) ---- */
void   dep_m_pan_to(double x, double y, double dur, const char *feel);
void   dep_m_pan_by(double dx, double dy, double dur, const char *feel);
void   dep_m_follow(double x, double y, double speed);  /* call every frame */
void   dep_m_follow_off(void);                          /* release camera */

/* ---- particles ---- */
enum {
    DEP_PK_SPARK = 0, DEP_PK_CONFETTI, DEP_PK_SMOKE, DEP_PK_STAR,
    DEP_PK_FIRE, DEP_PK_BUBBLE, DEP_PK_HEART, DEP_PK_RAIN, DEP_PK_SNOW,
    DEP_PK_CUSTOM
};
int dep_m_particle_kind(const char *word);         /* -1 unknown */
/* col: 4 floats 0..1, or col[0] < 0 for the kind's own palette */
void   dep_m_burst(int kind, double n, double x, double y,
                   const float *col, double speed, double size, double life);
void   dep_m_rain(double rate, const float *col, double speed, double size,
                  double life);
void   dep_m_snow(double rate, const float *col, double speed, double size,
                  double life);
void   dep_m_clear_particles(void);
long   dep_m_particle_count(void);
/* one particle, copied out (game kit renders by kind) */
typedef struct {
    float x, y, vx, vy, life, maxlife, size;
    float r, g, b, a, rot, grav, flut, phase;
    int   kind;
} MParticleView;
int    dep_m_particle_at(long i, MParticleView *out);

/* ---- clock ---- */
void   dep_motion_tick(double dt);                 /* one frame of motion */
void   dep_motion_advance(double seconds);         /* hand-step (console/tests) */
void   dep_m_set_screen(double w, double h);       /* game kit calls each frame */

/* ---- engine self-test (developer tool) ---- */
int    dep_motion_selftest(void);

/* builtin wrappers (consume their DEPValue arguments) */
double dep_m_tl_playing_v(DEPValue name);
double dep_m_tl_finished_v(DEPValue name);
double dep_m_particle_count_v(void);
double dep_m_moving_v(DEPValue target);   /* never valid at runtime: emitter
                                             resolves 'moving x.y' statically */

#ifdef __cplusplus
}
#endif
#endif /* DEP_MOTIONKIT_H */
